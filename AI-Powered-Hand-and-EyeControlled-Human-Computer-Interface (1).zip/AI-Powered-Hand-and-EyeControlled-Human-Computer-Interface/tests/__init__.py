"""
Test Suite for AI-Powered Hand and Eye Controlled HCI

Run tests with: pytest tests/ -v
"""
