"""
AI-Powered Hand and Eye Controlled Human-Computer Interface

A software system that allows users to control a computer mouse using 
natural hand and eye gestures, utilizing OpenCV and MediaPipe.
"""

__version__ = "0.1.0"
__author__ = "Sundas Safder, Benish Batool, Pakiza Imran"
